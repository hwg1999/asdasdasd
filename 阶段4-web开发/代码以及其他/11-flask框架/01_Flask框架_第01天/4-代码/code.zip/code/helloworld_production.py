from flask import Flask
import json


# 配置对象方式加载配置信息
class DefaultConfig(object):
    """
    默认配置
    """
    SECRET_KEY = 'hohph'

#
# class DevelopmentConfig(DefaultConfig):
#     DEBUG = True


def create_flask_app(config):
    """构建flask对象的工厂函数"""
    app = Flask(__name__, static_url_path='/s', static_folder='static_files')

    # 设置
    app.config.from_object(config)

    app.config.from_envvar('PROJECT_SETTING')

    return app


app = create_flask_app(DefaultConfig)
# app = create_flask_app(DevelopmentConfig)


# 定义视图
@app.route('/')
def index():
    # 读取配置信息
    print(app.config['SECRET_KEY'])
    return 'hello world'

print(app.url_map)  # -> Map对象
# 需求需要遍历url_map  取出特定信息 在一个特定的接口返回
# for rule in app.url_map.iter_rules():
#     print('name={} path={}'.format(rule.endpoint, rule.rule))
# endpoint -> 视图函数名
# rule -> 路径

# @app.route('/')
# def route_map():
#     """
#     主视图，返回所有视图网址
#     """
#     rules_iterator = app.url_map.iter_rules()
#     # {'index': '/', 'static': '/s/xxx}
#     return json.dumps({rule.endpoint: rule.rule for rule in rules_iterator})





# if __name__ == '__main__':
#     # 运行flask提供的调试服务器
#     app.run(host="0.0.0.0", port=8000)

# flask run  <===>  python -m flask run