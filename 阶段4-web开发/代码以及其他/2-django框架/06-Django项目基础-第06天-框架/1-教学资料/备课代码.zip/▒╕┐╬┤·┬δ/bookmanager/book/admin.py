from django.contrib import admin
from .models import BookInfo,PeopleInfo
# Register your models here.

class Inline(admin.StackedInline):
    model = PeopleInfo
    extra = 2


class BookInfoAdmin(admin.ModelAdmin):

    #设置显示字段
    list_display = ['id','name','readcount','commentcount','title']
    #设置删除操作的显示位置
    actions_on_bottom = True
    actions_on_top = True
    #设置筛选
    list_filter = ['name']
    #设置搜索框
    search_fields = ['name']

    #编辑页
    #设置显示字段
    # fields = ['name','readcount','commentcount']

    # fieldsets = (
    #     ('基本信息',{'fields':['name']}),
    #     ('高级信息',{'fields':['readcount','commentcount']}),
    # )

    #关联数据
    inlines = [Inline]

admin.site.register(BookInfo,BookInfoAdmin)

admin.site.register(PeopleInfo)

admin.site.index_title = 'index_title'
admin.site.site_title = 'site_title'
admin.site.site_header = 'header'
