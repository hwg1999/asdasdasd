from flask import Flask

#
# # 配置对象方式加载配置信息
# class DefaultConfig(object):
#     """
#     默认配置
#     """
#     SECRET_KEY = 'hohph'


app = Flask(__name__, static_url_path='/s', static_folder='static_files')

# 设置
# app.config.from_object(DefaultConfig)
# app.config.from_pyfile('setting.py')
# app.config.from_pyfile('/home/python/setting.py')


app.config.from_envvar('PROJECT_SETTING')
# app.config.from_envvar('PROJECT_SETTING', silent=True)

# 定义视图
@app.route('/')
def index():
    # 读取配置信息
    print(app.config['SECRET_KEY'])
    return 'hello world'


if __name__ == '__main__':
    app.run()
