from rest_framework import serializers
from .models import BookInfo,PeopleInfo

#定义一个继承自 serializers.Serializer的序列化器
class BookInfoSerializer(serializers.Serializer):
    #- Django文档
    #Serializer字段处理原始值和内部数据类型之间的转换。
    # 他们还处理验证输入值
    id = serializers.IntegerField(label='主键',read_only=True)
    name = serializers.CharField(label='书籍',max_length=20,min_length=1)
    pub_date = serializers.DateField(label='发布日期',allow_null=True,required=False)
    readcount = serializers.IntegerField(label='阅读量',required=False)
    commentcount = serializers.IntegerField(label='评论量',required=False)
    is_delete = serializers.BooleanField(label='逻辑删除',required=False,default=False)
    image = serializers.ImageField(label='图片',required=False)
    #反向获取数据中的人物
    #字段名要求必须为 关联模型类名小写_set
    #只读,注意 一对多的关系,添加 many=True
    peopleinfo_set = serializers.PrimaryKeyRelatedField(label='人物id',read_only=True,many=True)

class CustomRelateField(serializers.RelatedField):

    def to_representation(self, value):
        #value 表示 关联模型,即Book模型
        return 'Book: %d %s'%(value.id,value.name)

class PeopleInfoSerializer(serializers.Serializer):
    GENDER_CHOICES = (
        (0, 'male'),
        (1, 'female')
    )
    id = serializers.IntegerField(label='主键', read_only=True)
    name = serializers.CharField(label='人物', max_length=20, min_length=1)
    gender = serializers.ChoiceField(label='性别',choices=GENDER_CHOICES,default=0,required=False)
    description = serializers.CharField(label='描述',max_length=200,allow_null=True,required=False)

    #主要是book,book 关联着其他对象,可以通过不同的设置显示不同的数据,
    # 例如: "book":1, book:西游记, book:{}
    #有6种方式,我们主要演示3种
    #第一种,PerymaryKeyRelationField,以主键id的形式显示
    #要求,必须实现 queryset 或者 read_only=True
    book = serializers.PrimaryKeyRelatedField(label='书籍名',queryset=BookInfo.objects.all())
    #或者
    #book = serializers.PrimaryKeyRelatedField(label='书籍名',read_only=True)

    #第二种, StringField 来显示主键是 __str__ 方法数据
    #该字段是只读的
    # book = serializers.StringRelatedField(label='书籍名',read_only=True)

    #第三种, 序列化器 返回另外关联的序列化器内容
    # book = BookInfoSerializer()

    #第四种, 返回其他字段 SlugRelatedField,只能是关联表的字段
    #也是只读字段
    # book = serializers.SlugRelatedField(label='书籍外键',slug_field='pub_date',read_only=True)

    #第五种,超链接的形式
    # book = serializers.HyperlinkedRelatedField(label='书籍外键',read_only=True,view_name='book-detail')

    # 第六种,重写 serializer.RelatedField 的 to_representation方法
    # book = CustomRelateField(label='外键',read_only=True)

class BookSerializer(serializers.ModelSerializer):

    #实现以下代码
    class Meta:
        model = BookInfo    #指定模型类
        fields = '__all__' #指明所有字段
