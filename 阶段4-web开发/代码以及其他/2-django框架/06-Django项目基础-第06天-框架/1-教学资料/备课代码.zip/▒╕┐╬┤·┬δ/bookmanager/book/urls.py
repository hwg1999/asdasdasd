from django.conf.urls import url
from . import views
from .views import login_required

urlpatterns = [
    #位置参数
    url(r'^index/(\d+)/(\d+)/$',views.index,name='home'),
    #关键字参数,如果参数较多时,建议采用关键字参数
    url(r'^index/(?P<value1>\d+)/(?P<value2>\d+)/$',views.index,name='home'),

    # url(r'^register/$',views.register),

    url(r'^register/$',views.RegisterView.as_view()),

    # url(r'^center/$',login_required(views.CenterView.as_view())),
    url(r'^center/$',views.CenterView.as_view()),
]