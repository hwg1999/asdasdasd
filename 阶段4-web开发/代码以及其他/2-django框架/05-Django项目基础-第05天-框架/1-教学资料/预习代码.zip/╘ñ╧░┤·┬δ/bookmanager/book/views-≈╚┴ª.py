from django.shortcuts import render
from django.views.generic import View
from .models import BookInfo,PeopleInfo
from django.http import HttpResponse,JsonResponse
import json
from datetime import datetime
from rest_framework.viewsets import ModelViewSet
from .serializers import BookSerializer
# Create your views here.

#使用 DRF来实现刚才的功能
#DRF 来Flask的表单很像, 表单是需要创建一个 继承自 FlaskForm的类
#DRF 需要创建一个继承自 serializers.ModelSerializer
class BookViewSet(ModelViewSet):
    #实现以下两句代码
    queryset = BookInfo.objects.all()       #获取所有模型数据
    serializer_class = BookSerializer       #指明序列化器


#使用原生Django开发Restful风格接口,返回所有的数据都是JSON
#对于模型数据的操作
#查询所有书籍
#增加书籍
#查询一本书籍
#修改一本书籍
#删除一本书籍
#这5个行为 分在2个视图中
class BookListView(View):
    """
    查询所有图书和增加图书列表
    """

    def get(self,request):
        #通过模型获取所有数据
        books = BookInfo.objects.all()
        #将模型列表转换为字典列表
        book_list = []
        for book in books:
            book_list.append({
                'id':book.id,
                'name':book.name,
                'pub_date':book.pub_date,
                'readcount':book.readcount,
                'commentcount':book.commentcount,
                'image':book.image.url if book.image else ''
            })
        #返回JsonResponse实例对象
        return JsonResponse(book_list,safe=False)

    def post(self,request):

        #获取用户提交的数据
        json_bytes = request.body
        json_str = json_bytes.decode()
        book_dict = json.loads(json_str)
        #数据校验工作省略
        #数据入库

        book = BookInfo.objects.create(
            name=book_dict.get('name'),
            pub_date=datetime.strptime(book_dict.get('pub_date'),'%Y-%m-%d').date(),
            readcount=book_dict.get('readcount'),
            commentcount=book_dict.get('commentcount')
        )

        #返回响应,将刚刚入库的数据以JSON的形式响应
        return JsonResponse({
            'id':book.id,
            'name': book.name,
            'pub_date': book.pub_date,
            'readcount': book.readcount,
            'commentcount': book.commentcount,
            'image':book.image.url if book.image else ''
        })


class BookDetailView(View):
    """
    获取单个图书
    修改单个图书
    删除图书
    """

    def get(self,request,pk):
        #通过模型获取单个图书信息,并进行异常判断
        try:
            book = BookInfo.objects.get(pk=pk)
        except BookInfo.DoesNotExist:
            return HttpResponse(status=404)
        #将数据以JSON的形式返回
        return JsonResponse({
            'id':book.id,
            'name': book.name,
            'pub_date': book.pub_date,
            'readcount': book.readcount,
            'commentcount': book.commentcount,
            'image':book.image.url if book.image else ''
        })

    def put(self,request,pk):

        #获取要修改的书籍,注意捕获异常
        try:
            book = BookInfo.objects.get(pk=pk)
        except BookInfo.DoesNotExist:
            return HttpResponse(status=404)
        #获取用户提交的数据
        json_bytes = request.body
        json_str = json_bytes.decode()
        book_dict = json.loads(json_str)
        #数据校验省略

        #更新数据,并且保存
        book.name = book_dict.get('name',book.name)
        book.pub_date = datetime.strptime(book_dict.get('pub_date',book.pub_date),'%Y-%m-%d').date()
        book.readcount = book_dict.get('readcount',book.readcount)
        book.commentcount = book_dict.get('commentcount',book.commentcount)
        #将更新的数据以JSON的形式响应
        return JsonResponse({
            'id': book.id,
            'name': book.name,
            'pub_date': book.pub_date,
            'readcount': book.readcount,
            'commentcount': book.commentcount,
            'image': book.image.url if book.image else ''
        })


    def delete(self,request,pk):
        #通过模型查询指定书籍,注意进行异常捕获
        try:
            book = BookInfo.objects.get(pk=pk)
        except BookInfo.DoesNotExist:
            return HttpResponse(status=404)
        #删除
        book.delete()
        #返回响应
        return HttpResponse(status=204)





# class BookListView(View):
#     """
#     图书列表
#     """
#     def get(self,request):
#         #从模型中获取所有图书
#         books = BookInfo.objects.all()
#         #组织上下文
#         context = {
#             'books':books
#         }
#         #加载模板,并且返回响应
#         return render(request,'booklist.html',context)

