from django.conf.urls import url
from . import views
from rest_framework.routers import DefaultRouter

#创建路由对象
router = DefaultRouter()
#注册路由
router.register(r'books',views.BookViewSet,base_name='book')

urlpatterns = [
    # url(r'^books/$',views.BookListView.as_view()),
    # url(r'^books/(?P<pk>\d+)/$',views.BookDetailView.as_view()),
    url(r'^links/$',views.HyperLinkedView.as_view()),
]

#将DefaulRouter生成的路由信息添加到urlpatterns
urlpatterns += router.urls
