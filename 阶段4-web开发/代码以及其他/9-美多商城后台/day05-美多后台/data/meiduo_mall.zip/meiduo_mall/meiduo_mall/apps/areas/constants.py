# 设置地区缓存的过期时间
AREA_CACHE_EXPIRES = 60 * 60 * 2
