# 指定openid的有效时间
OPENID_EXPIRES = 60 * 5
