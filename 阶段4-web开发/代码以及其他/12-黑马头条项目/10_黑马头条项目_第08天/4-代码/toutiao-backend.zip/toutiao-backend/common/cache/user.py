from flask import current_app
import json
from sqlalchemy.orm import load_only
import random
from redis.exceptions import RedisError
from sqlalchemy.exc import DatabaseError

from models.user import User
from . import constants


# user1  UserCache(1) -> key='user:1:profile' get
# user2  UserCache(2) -> key='user:2:profile' get


class UserCache(object):
    """
    用户基本信息缓存工具类
    """

    def __init__(self, user_id):
        # redis数据记录的key 键
        self.key = 'user:{}:profile'.format(user_id)
        self.user_id = user_id

    # 类属性
    #   -> 所有对象共享类属性，也就是说所有对象中读取出的类属性 数据值都相同
    # 对象属性
    #  -> 每个对象单独所有，也就意味着每个对象的数据可以不同

    # 实例方法 （对象方法）
    # 类方法
    # 静态方法
    # 选择的依据：
    # 不同方法可以处理的类中的数据是不一样的
    #  对象方法-> 可以处理对象属性、类属性
    #  类方法-> 既可以通过类名也可以通过cls处理类属性
    #     @classmethod
    #     def func(cls, ...)
    # 静态方法  -> 通过类名可以处理类型属性 UserCache.key
    #    @staticmethod
    #    def func()

    def save(self):
        """
        保存缓存记录
        :return:
        """
        r = current_app.redis_cluster
        try:
            user = User.query.options(load_only(
                User.mobile,
                User.name,
                User.profile_photo,
                User.introduction,
                User.certificate
            )).filter_by(id=self.user_id).first()
        except DatabaseError as e:
            current_app.logger.error(e)
            # 对于这个数据库异常，我们自己封装的get方法无法为调用者做决定，决定返回什么值，所以抛出异常给调用者，由调用者决定
            raise e

        # 在django中 查询单一对象，而数据库不存在，抛出异常  User.DoesNotExists
        # 在sqlalchemy中，查询单一对象，数据库不存爱，不抛出异常，只返回None
        if user is None:
            # 数据库不存在
            try:
                r.setex(self.key, constants.UserNotExistCacheTTL.get_value(), -1)
            except RedisError as e:
                current_app.logger.error(e)

            return None
        else:
            user_dict = {
                'mobile': user.mobile,
                'name': user.name,
                'photo': user.profile_photo,
                'intro': user.introduction,
                'certi': user.certificate
            }
            try:
                r.setex(self.key, constants.UserCacheDataTTL.get_value(), json.dumps(user_dict))
            except RedisError as e:
                current_app.logger.error(e)

            return user_dict


    def get(self):
        """
        获取缓存数据
        :return: user dict
        """
        # 先查询redis缓存记录
        # 如果有记录 直接返回
        # 如果没有记录，查询数据库
        #      数据库中如果有记录，设置redis记录  json string
        #      数据库中如果没有记录，设置redis保存不存在的记录 -1
        # 返回
        r = current_app.redis_cluster
        try:
            ret = r.get(self.key)
        except RedisError as e:
            # 记录日志
            current_app.logger.error(e)
            # 在redis出现异常的时候，为了保证我们封装的get方法还能有返回值，可以进入数据库查询的部分
            ret = None

        if ret is not None:
            # 表示redis中有记录值
            # 判断redis记录是表示数据库不存在的-1值还是有意义的缓存记录
            # 切记： python3 从redis中取出的字符串数据是python中的bytes
            if ret == b'-1':
                return None
            else:
                # json.loads方法可以接受bytes类型
                user_dict = json.loads(ret)
                return user_dict
        else:
            return self.save()

    def clear(self):
        """
        清除缓存记录
        :return:
        """
        try:
            r = current_app.redis_cluster
            r.delete(self.key)
        except RedisError as e:
            current_app.logger.error(e)

    def determine_user_exists(self):
        """
        通过缓存判断用户id是否存在
        :return: boolean True：存在  False：不存在
        """
        # 查询redis
        # 如果存在Redis记录
        #   如果redis记录为-1,表示不存在
        #   如果redis记录不为-1， 表示用户存在

        # 如果不存在redis记录
        #   去数据库查询，判断是否存在
        #   设置redis缓存记录
        r = current_app.redis_cluster
        try:
            ret = r.get(self.key)
        except RedisError as e:
            # 记录日志
            current_app.logger.error(e)
            # 在redis出现异常的时候，为了保证我们封装的get方法还能有返回值，可以进入数据库查询的部分
            ret = None

        if ret is not None:
            # 表示redis中有记录值
            # 判断redis记录是表示数据库不存在的-1值还是有意义的缓存记录
            # 切记： python3 从redis中取出的字符串数据是python中的bytes
            if ret == b'-1':
                return False
            else:
                return True
        else:
            ret = self.save()
            if ret is not None:
                return True
            else:
                return False


