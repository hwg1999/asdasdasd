from rest_framework import serializers
from .models import BookInfo,PeopleInfo
class BookSerializer(serializers.ModelSerializer):

    #实现以下代码
    class Meta:
        model = BookInfo    #指定模型类
        fields = '__all__' #指明所有字段
