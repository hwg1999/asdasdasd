# Celery配置文件

# 指定中间人、消息队列、任务队列、容器，使用redis
broker_url = "redis://192.168.103.168/10"
