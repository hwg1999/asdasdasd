from django.shortcuts import render
from django.urls import reverse
from django.core.urlresolvers import reverse
import json
from django.http import HttpResponse,JsonResponse,HttpResponseRedirect
from django.views import View
# Create your views here.

#视图装饰器

def login_required(func):

    def wrapper(request,*args,**kwargs):
        if False:
            return func(request,*args,**kwargs)
        else:
            return HttpResponse('未登录')
    return wrapper

from django.utils.decorators import method_decorator

#Python 多继承特性 -- Mixin扩展
class LoginRequiredMixin(object):

    @classmethod
    def as_view(cls,**kwargs):

        view = super().as_view(**kwargs)
        view = login_required(view)
        return view

#第一个参数为 方法名
#第二个参数为 应用的方法名
# @method_decorator(login_required,name='dispatch')
class CenterView(LoginRequiredMixin,View):

    #当然我们也可以应用在每个方法上
    # @method_decorator(login_required)
    def get(self,request):

        return HttpResponse('个人中心展示')

    def post(self,request):
        return HttpResponse('个人中心修改')

class RegisterView(View):

    def get(self,request):

        return HttpResponse('get')

    def post(self,request):

        return HttpResponse('post')


def register(request):
    #通过 request.method来区分不同的请求,实现不同的路基
    if request.method == 'GET':
        return HttpResponse('get')
    else:
        return HttpResponse('post')

    return HttpResponse('ok')

def index(request,value1,value2):

    ######################请求部分########################
    # path = reverse('home')
    #设置了 namespace 之后,就要采用 namespace:name的形式来获取url
    # path = reverse('book:home')
    # print(path)

    # 提取URL的特定部分，如 / weather / beijing / 2018，可以在服务器端的路由中用正则表达式截取；
    print(value1,value2)
    # 查询字符串（querystring)，形如key1 = value1 & key2 = value2；
    #http://127.0.0.1:8000/index/1/100/?a=100&b=200&b=python
    params = request.GET
    print(params)
    a = params.get('a')
    b = params.getlist('b')
    print(a,b)
    # 请求体（body）中发送的数据，比如表单数据、json、xml；
    #POST方式提交表单数据
    a = request.POST.get('a')
    b = request.POST.getlist('b')
    print(a,b)
    #提交JSON数据
    # body_bytes = request.body
    # # print(body_bytes)
    # json_str = body_bytes.decode()
    # # print(json_str)
    # json_dict = json.loads(json_str)
    # print(json_dict)
    # # 在http报文的头（header）中。
    # print(request.META)
    # print(request.META['CONTENT_TYPE'])
    #############################状态保持#############################
    #cookie
    response = HttpResponse('cookie')
    #设置cookie
    response.set_cookie('cart','1')
    #删除cookie
    response.delete_cookie('cart')
    #读取cookie
    cart = request.COOKIES.get('cart')

    #session
    #设置session
    request.session['name'] = 'itcast'
    #获取数据
    name = request.session.get('name')
    print(name)
    #删除一条数据
    del request.session['name']
    print(request.session.get('name'))
    #删除所有数据
    request.session.clear()
    #删除整个session,包括session记录
    request.session.flush()
    #设置session的有效期
    # request.session.set_expiry(value)

    return response


    ############################响应部分#######################################

    return HttpResponseRedirect('http://www.itheima.com')
    return JsonResponse({'name':'阿三'})

    response = HttpResponse('ok')
    response['name'] = 'itcast' # 设置响应码
    response.status_code = 400 #设置响应码
    return response

    return render(request,'index.html')