from flask import current_app

from redis.exceptions import ConnectionError


# class UserArticleCountStorage(object):
#     """
#     用户文章数量redis存储工具类
#     """
#
#     # 在redis中一条记录保存了所有用户的而文章数量
#     # 'count:user:arts' redis  zset
#     # [
#     #     值          score
#     #     user_id   文章数量
#     #     (user_id_1, 12w),
#     #     (user_id_3, 10)
#     # ]
#
#     key = 'count:user:arts'
#
#     # 方式一
#     # cache_static.UserArticleCountStorage(user_id).get()
#     # def __init__(self, user_id):
#     #     self.user_id = user_id
#     #
#     # def get(self):
#     #     pass
#
#     # 方式二
#     # cache_static.UserArticleCountStorage.get(user_id)
#
#     @classmethod
#     def get(cls, user_id):
#         # 查询redis记录
#         # 如果redis存在记录
#         # 返回
#         # 如果redis不存在记录，则返回0，表示用户没有发表过文章
#         try:
#             count = current_app.redis_master.zscore(cls.key, user_id)
#         except ConnectionError as e:
#             current_app.logger.error(e)
#             count = current_app.redis_slave.zscore(cls.key, user_id)
#
#         if count is None:
#             return 0
#         else:
#             return int(count)
#
#     @classmethod
#     def increment(cls, user_id, incr_num=1):
#         try:
#             current_app.redis_master.zincrby(cls.key, user_id, incr_num)
#         except ConnectionError as e:
#             current_app.logger.error(e)
#             raise e


class CountStorageBase(object):
    """
    统计数量存储的父类
    """
    key = ''

    @classmethod
    def get(cls, user_id):
        # 查询redis记录
        # 如果redis存在记录
        # 返回
        # 如果redis不存在记录，则返回0，表示用户没有发表过文章
        try:
            count = current_app.redis_master.zscore(cls.key, user_id)
        except ConnectionError as e:
            current_app.logger.error(e)
            count = current_app.redis_slave.zscore(cls.key, user_id)

        if count is None:
            return 0
        else:
            return int(count)

    @classmethod
    def increment(cls, user_id, incr_num=1):
        try:
            current_app.redis_master.zincrby(cls.key, user_id, incr_num)
        except ConnectionError as e:
            current_app.logger.error(e)
            raise e


class UserArticleCountStorage(CountStorageBase):
    """
    用户文章数量redis存储工具类
    """
    key = 'count:user:arts'


class UserFollowingCountStorage(CountStorageBase):
    """
    用户关注数量
    """
    key = 'count:user:followings'


# POST /articles
#  视图 1. 保存新文章数据库数据
#       2. UserArticleCountStorage.increment(user_id, 1)

# 并不能一直保证数据库中保存的文章数量与redis中保存的统计数量是相同
# 需要使用定时任务，定时核查redis中的数量是否与数据库中数据一致
#   方式 构造定时任务
#     定时任务： 查询数据库，取出分组聚合数据，将数据设置到redis中