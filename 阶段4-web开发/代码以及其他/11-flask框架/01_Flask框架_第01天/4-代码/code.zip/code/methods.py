from flask import Flask


app = Flask(__name__, static_url_path='/s', static_folder='static_files')


# Django -> settings.py
# STATIC_DIR =['static_files']
# TEMPLATES_DIR = ['templates_files']
# SECRET_KEY


# 定义视图
@app.route('/', methods=['POST'])
def index():
    return 'hello world'


if __name__ == '__main__':
    app.run()
