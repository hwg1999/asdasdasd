

def mymiddleware(get_response):
    print('第一次初始化')
    def middleware(request):
        print('请求之前')
        response = get_response(request)
        print('响应后')
        return response

    return middleware

def mymiddleware2(get_response):
    print('第一次初始化2')
    def middleware(request):
        print('请求之前2')
        response = get_response(request)
        print('响应后2')
        return response

    return middleware
